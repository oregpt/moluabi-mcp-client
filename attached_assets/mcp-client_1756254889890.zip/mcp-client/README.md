# MoluAbi MCP Client

> **Standalone Command-Line Interface for MoluAbi AI Agent Management**

This is a **Model Context Protocol (MCP) client** that provides programmatic access to MoluAbi's AI agent management platform. It connects to the MoluAbi MCP server to create, manage, and interact with AI assistants through a beautiful command-line interface.

## 🎯 What This Does

This client allows you to **manage MoluAbi AI agents without using the web interface**:

- **Create agents** with custom instructions and capabilities
- **Chat with agents** in real-time through the terminal
- **Manage team access** by adding/removing users via email
- **Monitor usage** and costs for all your agents
- **List and organize** all accessible agents
- **Delete agents** safely with confirmation prompts

All operations sync perfectly with the MoluAbi web platform - agents created here appear in the web UI and vice versa.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ installed
- Access to a running MoluAbi MCP server
- Database connection (same as MoluAbi platform)

### Installation

```bash
# Clone or copy this directory anywhere
cd mcp-client

# Install dependencies
npm install

# Set up environment (copy from MoluAbi platform)
cp .env.example .env
# Edit .env with your database URL
```

### Basic Usage

```bash
# Interactive mode (recommended for first-time users)
npm run cli interactive

# Or use specific commands directly
npm run cli create      # Create a new agent
npm run cli list        # List your agents  
npm run cli chat        # Chat with an agent
npm run cli tools       # View available operations
```

## 📋 Available Commands

| Command | Description | Example |
|---------|-------------|---------|
| `interactive` | Full guided experience | `npm run cli interactive` |
| `create` | Create new agent | `npm run cli create` |
| `list` | Show all your agents | `npm run cli list` |
| `chat` | Chat with an agent | `npm run cli chat` |
| `users` | Manage agent access | `npm run cli users` |
| `delete` | Remove an agent | `npm run cli delete` |
| `tools` | Show available MCP tools | `npm run cli tools` |

## 🎮 Example Workflow

### 1. Create Your First Agent
```bash
npm run cli create
```
Follow the prompts to:
- Name your agent (e.g., "Customer Support Bot")
- Add description and instructions
- Choose agent type (file-based, team, hybrid)
- Set visibility (public/private)

### 2. Chat With Your Agent
```bash
npm run cli chat
```
- Enter the agent ID from step 1
- Start chatting! Type 'exit' to quit

### 3. Manage Team Access
```bash
npm run cli users
```
- Add teammates by email
- Grant or revoke access to specific agents

## 🔧 How It Works

### MCP Connection
The client uses the **Model Context Protocol** to communicate with the MoluAbi server:

```typescript
// Connects to MoluAbi MCP server automatically
const client = new MoluAbiMCPClient();
await client.connect();

// Uses 10 available MCP tools:
// create_agent, list_agents, prompt_agent, etc.
```

### Tool Integration
The client exposes **10 MCP tools** for complete agent management:

1. **create_agent** - Build new AI assistants
2. **list_agents** - Query accessible agents
3. **get_agent** - Retrieve agent details
4. **update_agent** - Modify agent settings
5. **delete_agent** - Remove agents safely
6. **prompt_agent** - Send messages and get responses
7. **add_user_to_agent** - Grant team access
8. **remove_user_from_agent** - Revoke access
9. **get_usage_report** - Monitor costs and usage
10. **get_pricing** - View current pricing

## 🎨 Features

### Beautiful CLI Interface
- **Interactive prompts** with validation
- **Colorful output** with status indicators
- **Table formatting** for agent lists
- **Progress spinners** during operations
- **Error handling** with helpful messages

### Real-Time Chat
```
You: How do I reset my password?
🤖 Agent is thinking...

Customer Support Bot: I can help you reset your password! Here are the steps:
1. Go to the login page
2. Click "Forgot Password"
3. Enter your email address...

[Tokens: 156]
```

### Team Management
- Add users by email address
- Automatic validation and error handling
- Sync with web platform permissions

## 🔐 Security & Configuration

### Environment Setup
```bash
# Required: Database connection to MoluAbi platform
DATABASE_URL=postgresql://user:pass@host:5432/moluabi
```

### MCP Server Connection
The client automatically connects to the MoluAbi MCP server using:
- **Command**: `npx tsx ../mcp-server/src/server.ts`
- **Transport**: Standard I/O (stdio)
- **Authentication**: Database-based user validation

## 📁 Project Structure

```
mcp-client/
├── src/
│   ├── lib/
│   │   └── mcp-client.ts      # Core MCP client logic
│   ├── commands/
│   │   └── agent-commands.ts  # CLI command implementations
│   ├── cli.ts                 # Command-line interface
│   └── index.ts               # Demo/testing entry point
├── package.json               # Dependencies and scripts
├── tsconfig.json             # TypeScript configuration
└── README.md                 # This file
```

## 🔄 Standalone Usage

This client is **completely independent** and can be:

- **Moved anywhere** - Copy this entire directory to any location
- **Used separately** - No need for the main MoluAbi web platform code
- **Distributed** - Share with team members as a standalone tool
- **Customized** - Modify for your specific workflow needs

The only requirement is access to a running MoluAbi MCP server.

## 🎯 Use Cases

### For Developers
- **Automate** agent creation in CI/CD pipelines
- **Script** bulk operations and management
- **Integrate** with existing terminal workflows
- **Test** agents quickly without opening browser

### For Teams  
- **Onboard** new members via command line
- **Manage** permissions programmatically
- **Monitor** usage across all team agents
- **Share** agents efficiently

### For Power Users
- **Quick prototyping** of AI assistants
- **Bulk operations** on multiple agents
- **Terminal-native** workflow integration
- **Offline-first** agent management

## 💡 Tips & Tricks

### Interactive Mode
Start with `npm run cli interactive` for a guided experience that walks you through all available operations.

### Quick Commands
```bash
# Create and immediately chat with new agent
npm run cli create && npm run cli chat

# Check all tools available
npm run cli tools

# List agents in table format
npm run cli list
```

### Error Handling
The client provides helpful error messages and automatically handles:
- Connection failures to MCP server
- Invalid user IDs or agent IDs
- Permission errors
- Network timeouts

## 🔗 Integration

This MCP client demonstrates the power of the **Model Context Protocol** for AI agent management. It can be:

- **Extended** with additional MCP tools
- **Integrated** into other applications
- **Used as reference** for building custom MCP clients
- **Deployed** as part of larger automation systems

The MCP architecture ensures that this client stays in perfect sync with the main MoluAbi platform while providing a completely different user experience.

---

**Built with ❤️ for the AI agent ecosystem**

*Experience the power of programmatic AI agent management*