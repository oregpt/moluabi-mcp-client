import { MoluAbiMCPClient, CreateAgentRequest } from "../lib/mcp-client.js";
import inquirer from "inquirer";
import chalk from "chalk";
import { table } from "table";

export class AgentCommands {
  constructor(private client: MoluAbiMCPClient) {}

  async createAgentInteractive(): Promise<void> {
    console.log(chalk.blue.bold("\n🤖 Creating New AI Agent\n"));

    const answers = await inquirer.prompt([
      {
        type: "input",
        name: "name",
        message: "Agent name:",
        validate: (input) => input.trim().length > 0 || "Name is required",
      },
      {
        type: "input",
        name: "description",
        message: "Agent description:",
      },
      {
        type: "editor",
        name: "instructions",
        message: "Agent instructions (opens editor):",
        default: "You are a helpful AI assistant. Always be polite and provide accurate information.",
      },
      {
        type: "input",
        name: "userId",
        message: "Your user ID:",
        validate: (input) => input.trim().length > 0 || "User ID is required",
      },
      {
        type: "list",
        name: "type",
        message: "Agent type:",
        choices: [
          { name: "File-based (upload documents)", value: "file-based" },
          { name: "Team (collaborative agents)", value: "team" },
          { name: "Hybrid (files + capabilities)", value: "hybrid" },
        ],
        default: "file-based",
      },
      {
        type: "confirm",
        name: "isPublic",
        message: "Make agent publicly visible?",
        default: false,
      },
      {
        type: "confirm",
        name: "isShareable",
        message: "Allow sharing via direct links?",
        default: false,
      },
    ]);

    try {
      const agent = await this.client.createAgent(answers as CreateAgentRequest);
      
      console.log(chalk.green.bold("\n✅ Agent created successfully!\n"));
      console.log(chalk.cyan("Agent Details:"));
      console.log(`  ID: ${agent.id}`);
      console.log(`  Name: ${agent.name}`);
      console.log(`  Type: ${agent.type}`);
      console.log(`  Public: ${agent.isPublic ? "Yes" : "No"}`);
      console.log(`  Shareable: ${agent.isShareable ? "Yes" : "No"}`);
      console.log(`  Created: ${new Date(agent.createdAt).toLocaleString()}`);
      
    } catch (error) {
      console.error(chalk.red.bold("\n❌ Failed to create agent:"));
      console.error(chalk.red(error instanceof Error ? error.message : String(error)));
    }
  }

  async listAgents(): Promise<void> {
    console.log(chalk.blue.bold("\n📋 Your AI Agents\n"));

    const answers = await inquirer.prompt([
      {
        type: "input",
        name: "userId",
        message: "Your user ID:",
        validate: (input) => input.trim().length > 0 || "User ID is required",
      },
    ]);

    try {
      const agents = await this.client.listAgents(answers.userId);

      if (agents.length === 0) {
        console.log(chalk.yellow("No agents found. Create your first agent!"));
        return;
      }

      const tableData = [
        ["ID", "Name", "Type", "Public", "Created"],
        ...agents.map(agent => [
          agent.id.toString(),
          agent.name,
          agent.type,
          agent.isPublic ? "Yes" : "No",
          new Date(agent.createdAt).toLocaleDateString(),
        ]),
      ];

      console.log(table(tableData, {
        border: {
          topBody: "─",
          topJoin: "┬",
          topLeft: "┌",
          topRight: "┐",
          bottomBody: "─",
          bottomJoin: "┴",
          bottomLeft: "└",
          bottomRight: "┘",
          bodyLeft: "│",
          bodyRight: "│",
          bodyJoin: "│",
          joinBody: "─",
          joinLeft: "├",
          joinRight: "┤",
          joinJoin: "┼",
        },
      }));

    } catch (error) {
      console.error(chalk.red.bold("\n❌ Failed to list agents:"));
      console.error(chalk.red(error instanceof Error ? error.message : String(error)));
    }
  }

  async chatWithAgent(): Promise<void> {
    console.log(chalk.blue.bold("\n💬 Chat with Agent\n"));

    const setup = await inquirer.prompt([
      {
        type: "input",
        name: "agentId",
        message: "Agent ID to chat with:",
        validate: (input) => !isNaN(parseInt(input)) || "Agent ID must be a number",
      },
      {
        type: "input",
        name: "userId",
        message: "Your user ID:",
        validate: (input) => input.trim().length > 0 || "User ID is required",
      },
    ]);

    const agentId = parseInt(setup.agentId);
    const userId = setup.userId;

    try {
      // Get agent info first
      const agent = await this.client.getAgent(agentId, userId);
      console.log(chalk.green(`\n✅ Connected to agent: ${agent.name}`));
      console.log(chalk.gray(`Description: ${agent.description || "No description"}`));
      console.log(chalk.gray("Type 'exit' to quit the chat\n"));

      // Start chat loop
      while (true) {
        const { message } = await inquirer.prompt([
          {
            type: "input",
            name: "message",
            message: "You:",
          },
        ]);

        if (message.toLowerCase() === "exit") {
          console.log(chalk.blue("👋 Chat ended"));
          break;
        }

        if (!message.trim()) continue;

        try {
          console.log(chalk.gray("🤖 Agent is thinking..."));
          const response = await this.client.promptAgent(agentId, message, userId);
          
          console.log(chalk.green(`\n${agent.name}:`), response.response);
          
          if (response.usage) {
            console.log(chalk.gray(`\n[Tokens: ${response.usage.total_tokens || 0}]`));
          }
          console.log();
          
        } catch (error) {
          console.error(chalk.red("❌ Failed to get response:"), error instanceof Error ? error.message : String(error));
        }
      }

    } catch (error) {
      console.error(chalk.red.bold("\n❌ Failed to connect to agent:"));
      console.error(chalk.red(error instanceof Error ? error.message : String(error)));
    }
  }

  async deleteAgent(): Promise<void> {
    console.log(chalk.red.bold("\n🗑️ Delete Agent\n"));

    const answers = await inquirer.prompt([
      {
        type: "input",
        name: "agentId",
        message: "Agent ID to delete:",
        validate: (input) => !isNaN(parseInt(input)) || "Agent ID must be a number",
      },
      {
        type: "input",
        name: "userId",
        message: "Your user ID:",
        validate: (input) => input.trim().length > 0 || "User ID is required",
      },
    ]);

    const agentId = parseInt(answers.agentId);
    
    try {
      // Get agent details first
      const agent = await this.client.getAgent(agentId, answers.userId);
      
      const confirmation = await inquirer.prompt([
        {
          type: "confirm",
          name: "confirmed",
          message: `Are you sure you want to delete "${agent.name}"? This cannot be undone.`,
          default: false,
        },
      ]);

      if (!confirmation.confirmed) {
        console.log(chalk.yellow("🚫 Deletion cancelled"));
        return;
      }

      const success = await this.client.deleteAgent(agentId, answers.userId);
      
      if (success) {
        console.log(chalk.green.bold(`\n✅ Agent "${agent.name}" deleted successfully`));
      } else {
        console.log(chalk.red.bold("\n❌ Failed to delete agent"));
      }

    } catch (error) {
      console.error(chalk.red.bold("\n❌ Failed to delete agent:"));
      console.error(chalk.red(error instanceof Error ? error.message : String(error)));
    }
  }

  async manageUsers(): Promise<void> {
    console.log(chalk.blue.bold("\n👥 Manage Agent Users\n"));

    const setup = await inquirer.prompt([
      {
        type: "input",
        name: "agentId",
        message: "Agent ID:",
        validate: (input) => !isNaN(parseInt(input)) || "Agent ID must be a number",
      },
      {
        type: "input",
        name: "ownerId",
        message: "Your user ID (owner):",
        validate: (input) => input.trim().length > 0 || "User ID is required",
      },
      {
        type: "list",
        name: "action",
        message: "What would you like to do?",
        choices: [
          { name: "Add user to agent", value: "add" },
          { name: "Remove user from agent", value: "remove" },
        ],
      },
    ]);

    const agentId = parseInt(setup.agentId);

    const { userEmail } = await inquirer.prompt([
      {
        type: "input",
        name: "userEmail",
        message: "User email:",
        validate: (input) => {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          return emailRegex.test(input) || "Please enter a valid email address";
        },
      },
    ]);

    try {
      let success = false;
      
      if (setup.action === "add") {
        success = await this.client.addUserToAgent(agentId, userEmail, setup.ownerId);
        if (success) {
          console.log(chalk.green.bold(`\n✅ User ${userEmail} added to agent`));
        }
      } else {
        success = await this.client.removeUserFromAgent(agentId, userEmail, setup.ownerId);
        if (success) {
          console.log(chalk.green.bold(`\n✅ User ${userEmail} removed from agent`));
        }
      }

      if (!success) {
        console.log(chalk.red.bold("\n❌ Operation failed"));
      }

    } catch (error) {
      console.error(chalk.red.bold("\n❌ Operation failed:"));
      console.error(chalk.red(error instanceof Error ? error.message : String(error)));
    }
  }
}