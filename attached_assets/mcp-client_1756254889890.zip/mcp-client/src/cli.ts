#!/usr/bin/env node

import { Command } from "commander";
import chalk from "chalk";
import ora from "ora";
import { MoluAbiMCPClient } from "./lib/mcp-client.js";
import { AgentCommands } from "./commands/agent-commands.js";

const program = new Command();

program
  .name("moluabi-agent")
  .description("CLI tool for managing MoluAbi AI agents via MCP")
  .version("1.0.0");

async function withMCPClient<T>(action: (client: MoluAbiMCPClient) => Promise<T>): Promise<T> {
  const spinner = ora("Connecting to MoluAbi MCP Server...").start();
  const client = new MoluAbiMCPClient();
  
  try {
    await client.connect();
    spinner.succeed("Connected to MoluAbi MCP Server");
    
    const result = await action(client);
    return result;
  } catch (error) {
    spinner.fail("Failed to connect to MCP server");
    console.error(chalk.red(error instanceof Error ? error.message : String(error)));
    process.exit(1);
  } finally {
    await client.disconnect();
  }
}

program
  .command("create")
  .description("Create a new AI agent interactively")
  .action(async () => {
    await withMCPClient(async (client) => {
      const commands = new AgentCommands(client);
      await commands.createAgentInteractive();
    });
  });

program
  .command("list")
  .description("List your AI agents")
  .action(async () => {
    await withMCPClient(async (client) => {
      const commands = new AgentCommands(client);
      await commands.listAgents();
    });
  });

program
  .command("chat")
  .description("Start a chat session with an agent")
  .action(async () => {
    await withMCPClient(async (client) => {
      const commands = new AgentCommands(client);
      await commands.chatWithAgent();
    });
  });

program
  .command("delete")
  .description("Delete an agent")
  .action(async () => {
    await withMCPClient(async (client) => {
      const commands = new AgentCommands(client);
      await commands.deleteAgent();
    });
  });

program
  .command("users")
  .description("Manage agent user access")
  .action(async () => {
    await withMCPClient(async (client) => {
      const commands = new AgentCommands(client);
      await commands.manageUsers();
    });
  });

program
  .command("tools")
  .description("List available MCP tools")
  .action(async () => {
    await withMCPClient(async (client) => {
      const tools = await client.getAvailableTools();
      
      console.log(chalk.blue.bold("\n🔧 Available MCP Tools\n"));
      
      tools.forEach((tool, index) => {
        console.log(chalk.green(`${index + 1}. ${tool.name}`));
        console.log(chalk.gray(`   ${tool.description || "No description"}`));
        
        if (tool.inputSchema?.properties) {
          console.log(chalk.yellow("   Parameters:"));
          Object.entries(tool.inputSchema.properties).forEach(([key, value]: [string, any]) => {
            const required = tool.inputSchema.required?.includes(key) ? " (required)" : "";
            console.log(chalk.gray(`     - ${key}: ${value.type}${required}`));
          });
        }
        console.log();
      });
    });
  });

program
  .command("interactive")
  .alias("i")
  .description("Start interactive mode")
  .action(async () => {
    console.log(chalk.blue.bold("🤖 MoluAbi Agent Manager - Interactive Mode\n"));
    
    const inquirer = await import("inquirer");
    
    while (true) {
      const { action } = await inquirer.default.prompt([
        {
          type: "list",
          name: "action",
          message: "What would you like to do?",
          choices: [
            { name: "Create new agent", value: "create" },
            { name: "List my agents", value: "list" },
            { name: "Chat with agent", value: "chat" },
            { name: "Manage agent users", value: "users" },
            { name: "Delete agent", value: "delete" },
            { name: "View available tools", value: "tools" },
            new inquirer.default.Separator(),
            { name: "Exit", value: "exit" },
          ],
        },
      ]);

      if (action === "exit") {
        console.log(chalk.blue("👋 Goodbye!"));
        break;
      }

      try {
        await withMCPClient(async (client) => {
          const commands = new AgentCommands(client);
          
          switch (action) {
            case "create":
              await commands.createAgentInteractive();
              break;
            case "list":
              await commands.listAgents();
              break;
            case "chat":
              await commands.chatWithAgent();
              break;
            case "users":
              await commands.manageUsers();
              break;
            case "delete":
              await commands.deleteAgent();
              break;
            case "tools":
              const tools = await client.getAvailableTools();
              console.log(chalk.blue.bold("\n🔧 Available MCP Tools\n"));
              tools.forEach((tool, index) => {
                console.log(chalk.green(`${index + 1}. ${tool.name}`));
                console.log(chalk.gray(`   ${tool.description || "No description"}`));
              });
              break;
          }
        });
      } catch (error) {
        console.error(chalk.red("Operation failed:"), error);
      }

      console.log(); // Add spacing
    }
  });

// Handle errors
process.on("unhandledRejection", (error) => {
  console.error(chalk.red("Unhandled error:"), error);
  process.exit(1);
});

process.on("SIGINT", () => {
  console.log(chalk.blue("\n👋 Goodbye!"));
  process.exit(0);
});

program.parse(process.argv);