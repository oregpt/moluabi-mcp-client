import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { spawn } from "child_process";

export interface AgentData {
  id: number;
  name: string;
  description: string | null;
  instructions: string | null;
  type: string;
  isPublic: boolean;
  isShareable: boolean;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateAgentRequest {
  name: string;
  description?: string;
  instructions?: string;
  userId: string;
  type?: string;
  isPublic?: boolean;
  isShareable?: boolean;
}

export interface ChatResponse {
  response: string;
  usage?: {
    input_tokens?: number;
    output_tokens?: number;
    total_tokens?: number;
  };
}

export class MoluAbiMCPClient {
  private client: Client;
  private transport: StdioClientTransport;
  private isConnected = false;

  constructor() {
    // Initialize the MCP client that will connect to our MoluAbi MCP server
    this.transport = new StdioClientTransport({
      command: "npx",
      args: ["tsx", "../mcp-server/src/server.ts"],
      env: {
        ...process.env,
        DATABASE_URL: process.env.DATABASE_URL,
      },
    });

    this.client = new Client(
      {
        name: "moluabi-agent-creator",
        version: "1.0.0",
      },
      {
        capabilities: {},
      }
    );
  }

  async connect(): Promise<void> {
    if (this.isConnected) return;

    try {
      await this.client.connect(this.transport);
      this.isConnected = true;
      console.log("✅ Connected to MoluAbi MCP Server");
    } catch (error) {
      console.error("❌ Failed to connect to MCP server:", error);
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    if (!this.isConnected) return;

    try {
      await this.client.close();
      this.isConnected = false;
      console.log("✅ Disconnected from MoluAbi MCP Server");
    } catch (error) {
      console.error("❌ Error disconnecting:", error);
    }
  }

  private async callTool(name: string, arguments_: Record<string, any>): Promise<any> {
    if (!this.isConnected) {
      throw new Error("Not connected to MCP server. Call connect() first.");
    }

    try {
      const result = await this.client.callTool({
        name,
        arguments: arguments_,
      });

      if (result.isError) {
        throw new Error(`Tool call failed: ${result.content[0]?.text || 'Unknown error'}`);
      }

      return JSON.parse(result.content[0]?.text || '{}');
    } catch (error) {
      console.error(`❌ Tool call failed (${name}):`, error);
      throw error;
    }
  }

  // Agent Management Methods
  async createAgent(request: CreateAgentRequest): Promise<AgentData> {
    console.log(`🤖 Creating agent: ${request.name}`);
    return await this.callTool("create_agent", request);
  }

  async listAgents(userId: string): Promise<AgentData[]> {
    console.log("📋 Listing agents...");
    return await this.callTool("list_agents", { userId });
  }

  async getAgent(agentId: number, userId: string): Promise<AgentData> {
    console.log(`🔍 Getting agent: ${agentId}`);
    return await this.callTool("get_agent", { agentId, userId });
  }

  async updateAgent(agentId: number, updates: Partial<CreateAgentRequest>, userId: string): Promise<AgentData> {
    console.log(`📝 Updating agent: ${agentId}`);
    return await this.callTool("update_agent", { agentId, ...updates, userId });
  }

  async deleteAgent(agentId: number, userId: string): Promise<boolean> {
    console.log(`🗑️ Deleting agent: ${agentId}`);
    return await this.callTool("delete_agent", { agentId, userId });
  }

  // User Management Methods
  async addUserToAgent(agentId: number, userEmail: string, ownerId: string): Promise<boolean> {
    console.log(`👥 Adding user ${userEmail} to agent ${agentId}`);
    return await this.callTool("add_user_to_agent", { agentId, userEmail, ownerId });
  }

  async removeUserFromAgent(agentId: number, userEmail: string, ownerId: string): Promise<boolean> {
    console.log(`👥 Removing user ${userEmail} from agent ${agentId}`);
    return await this.callTool("remove_user_from_agent", { agentId, userEmail, ownerId });
  }

  // Agent Interaction Methods
  async promptAgent(agentId: number, message: string, userId: string): Promise<ChatResponse> {
    console.log(`💬 Sending message to agent ${agentId}: ${message.substring(0, 50)}...`);
    return await this.callTool("prompt_agent", { agentId, message, userId });
  }

  async uploadFileToAgent(agentId: number, filePath: string, userId: string): Promise<boolean> {
    console.log(`📁 Uploading file to agent ${agentId}: ${filePath}`);
    return await this.callTool("upload_file_to_agent", { agentId, filePath, userId });
  }

  // Utility Methods
  async getUsageReport(userId: string, startDate?: string, endDate?: string): Promise<any> {
    console.log("📊 Getting usage report...");
    return await this.callTool("get_usage_report", { userId, startDate, endDate });
  }

  async getAvailableTools(): Promise<any[]> {
    if (!this.isConnected) {
      throw new Error("Not connected to MCP server");
    }

    try {
      const response = await this.client.listTools();
      return response.tools;
    } catch (error) {
      console.error("❌ Failed to get available tools:", error);
      throw error;
    }
  }
}