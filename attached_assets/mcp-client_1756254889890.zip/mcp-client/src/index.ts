import { MoluAbiMCPClient } from "./lib/mcp-client.js";
import chalk from "chalk";

async function main() {
  console.log(chalk.blue.bold("🤖 MoluAbi MCP Client Demo\n"));

  const client = new MoluAbiMCPClient();
  
  try {
    // Connect to the MCP server
    await client.connect();
    
    // Demo: List available tools
    console.log(chalk.green("📋 Available MCP Tools:"));
    const tools = await client.getAvailableTools();
    tools.forEach(tool => {
      console.log(chalk.cyan(`  • ${tool.name}: ${tool.description || "No description"}`));
    });
    
    console.log(chalk.yellow("\n💡 Use 'npm run cli' for interactive mode"));
    console.log(chalk.yellow("   Or 'npm run cli -- --help' for all commands"));
    
  } catch (error) {
    console.error(chalk.red("❌ Demo failed:"), error);
  } finally {
    await client.disconnect();
  }
}

main().catch(console.error);